# Bazel Execve Mitigation Skeleton

## Overview
This is a mitigation skeleton addressing untrusted `execve` behavior.
The patch ensures stricter handling of allowed exec calls and provides
a minimal basis for discussion in a PR.

## Files
- patch.diff : Proposed mitigation (skeleton)
- WORKSPACE  : Placeholder for Bazel workspace setup
- BUILD      : Placeholder for testing rules
