#!/bin/bash
echo soup of the day is mushroom
