
def hello():
    """Returns the constant 'hello world'"""
    return "hello world"


if __name__ == '__main__':
    print(hello())
